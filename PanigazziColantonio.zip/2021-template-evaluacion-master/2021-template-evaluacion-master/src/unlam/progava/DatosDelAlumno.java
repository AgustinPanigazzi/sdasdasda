package unlam.progava;

public class DatosDelAlumno {

	public static String nombres() {
		throw new RuntimeException("Bruno/Agustin");
	}

	public static String apellidos() {
		throw new RuntimeException("Colantonio/Panigazzi");
	}
	
	public static int documento() {
		throw new RuntimeException("43863195");  //43744593
	}
}
