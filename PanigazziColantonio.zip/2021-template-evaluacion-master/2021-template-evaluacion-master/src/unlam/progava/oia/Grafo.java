package unlam.progava.oia;

import java.util.ArrayList;
import java.util.PriorityQueue;

public class Grafo {

		private int matrizAdy[][];
		private int nodoInicial;
		private int[] padre;

		public Grafo(int matriz[][]) {
			this.matrizAdy = matriz;
			this.padre = new int[matrizAdy.length];
		}

		public int dijkstra(int nodoInicial) {
			int distancia[] = new int[matrizAdy.length];
			boolean visitado[] = new boolean[matrizAdy.length];
			int infinito = Integer.MAX_VALUE;
			int tiradas = 0;
			int costoAct = 0;

			PriorityQueue<Nodo> pq = new PriorityQueue<Nodo>();


			for (int i = 0; i < matrizAdy.length; i++) {
				distancia[i] = infinito;
				padre[i] = infinito;
				visitado[i] = false;
			}

			distancia[nodoInicial] = 0;
			pq.add(new Nodo(nodoInicial, distancia[nodoInicial]));

			while (!pq.isEmpty()) {
				Nodo nodo = pq.remove();
				int nodoActual = nodo.getNodo();
				visitado[nodoActual] = true;

				for (int i = 0; i < matrizAdy.length; i++) {
					if (matrizAdy[nodoActual][i] >= 0 && matrizAdy[nodoActual][i]!=infinito) {
						if (!visitado[i] && (distancia[i] > (distancia[nodoActual] + matrizAdy[nodoActual][i]))) {
							costoAct +=  distancia[nodoActual] + matrizAdy[nodoActual][i];
							if(matrizAdy[nodoActual][i]==0){
								tiradas++;
								costoAct=0;
							}
							if(costoAct==6){
								tiradas++;
								costoAct=0;
							}
							distancia[i] = distancia[nodoActual] + matrizAdy[nodoActual][i];
							padre[i] = nodoActual;
							pq.add(new Nodo(i, distancia[i]));
						}
					}
				}
			}
			if(costoAct>0){
				tiradas++;
			}

			return tiradas;
		}

}
